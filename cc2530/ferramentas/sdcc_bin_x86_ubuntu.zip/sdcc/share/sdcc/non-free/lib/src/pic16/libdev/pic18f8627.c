/*
 * pic18f8627.c - device specific definitions
 */
#include "pic18f8722.c"
