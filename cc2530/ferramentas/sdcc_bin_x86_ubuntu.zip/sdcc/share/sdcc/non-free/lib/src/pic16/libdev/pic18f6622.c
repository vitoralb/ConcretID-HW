/*
 * pic18f6622.c - device specific definitions
 */
#include "pic18f8722.c"
