/*
 * pic18f2410.c - device specific definitions
 */

#include "pic18f4610.c"

