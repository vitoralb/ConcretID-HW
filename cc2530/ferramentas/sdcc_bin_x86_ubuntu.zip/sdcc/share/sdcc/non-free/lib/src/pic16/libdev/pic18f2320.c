/*
 * pic18f2320.c - PIC18F2320 Device Library Source
 *
 * This file is part of the GNU PIC Library.
 *
 * January, 2004
 * The GNU PIC Library is maintained by,
 * 	Vangelis Rokas <vrokas@otenet.gr>
 *
 * $Id: pic18f2320.c 6002 2010-10-04 19:54:39Z borutr $
 *
 */

#include "pic18f2220.c"

