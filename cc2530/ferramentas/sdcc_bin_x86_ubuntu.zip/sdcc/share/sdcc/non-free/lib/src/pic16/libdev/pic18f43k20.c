/*
 * pic18f43k20.c - device specific definitions
 */

#include "pic18f46k20.c"

