/*
 * pic18f2480.c - device specific definitions
 */

#include "pic18f4580.c"

