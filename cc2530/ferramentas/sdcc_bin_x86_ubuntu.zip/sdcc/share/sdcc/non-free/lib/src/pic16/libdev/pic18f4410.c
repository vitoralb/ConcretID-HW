/*
 * pic18f4410.c - device specific definitions
 */

#include "pic18f4610.c"

