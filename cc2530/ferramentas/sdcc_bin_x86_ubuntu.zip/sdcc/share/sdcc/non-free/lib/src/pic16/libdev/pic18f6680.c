/*
 * pic18f6680.c - device specific definitions
 */

#include "pic18f8680.c"

