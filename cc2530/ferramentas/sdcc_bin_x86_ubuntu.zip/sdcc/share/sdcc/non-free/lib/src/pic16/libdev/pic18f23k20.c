/*
 * pic18f23k20.c - device specific definitions
 */

#include "pic18f46k20.c"

