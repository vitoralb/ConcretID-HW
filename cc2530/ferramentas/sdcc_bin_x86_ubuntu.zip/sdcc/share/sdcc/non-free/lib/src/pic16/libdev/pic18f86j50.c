/*
 * pic18f86j50.c - device specific definitions
 */

#include <pic18f86j50.h>
#include "pic18f87j50.c"

