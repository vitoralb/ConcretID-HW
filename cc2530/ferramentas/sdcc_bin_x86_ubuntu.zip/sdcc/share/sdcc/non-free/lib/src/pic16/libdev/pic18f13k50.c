/*
 * pic18f13k50.c - device specific definitions
 */
#include "pic18f14k50.c"
