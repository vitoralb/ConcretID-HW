/*
 * pic18f4510.c - device specific definitions
 */

#include "pic18f4610.c"

