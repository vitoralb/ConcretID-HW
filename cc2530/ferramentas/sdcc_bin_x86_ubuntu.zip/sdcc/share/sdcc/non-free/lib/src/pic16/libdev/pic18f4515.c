/*
 * pic18f4515.c - device specific definitions
 */

#include "pic18f4610.c"

