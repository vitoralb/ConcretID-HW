/*
 * pic18f2523.c - device specific definitions
 */

#include "pic18f4523.c"

