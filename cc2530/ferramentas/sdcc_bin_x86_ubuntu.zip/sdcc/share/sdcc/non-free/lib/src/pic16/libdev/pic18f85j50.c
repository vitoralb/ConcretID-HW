/*
 * pic18f85j50.c - device specific definitions
 */

#include <pic18f85j50.h>
#include "pic18f87j50.c"

