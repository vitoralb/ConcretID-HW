/*
 * pic18f86j65.c - device specific definitions
 */

#include "pic18f86j60.c"

