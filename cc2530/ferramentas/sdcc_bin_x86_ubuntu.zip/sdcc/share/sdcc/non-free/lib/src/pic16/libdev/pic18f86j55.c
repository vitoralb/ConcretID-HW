/*
 * pic18f86j55.c - device specific definitions
 */

#include <pic18f86j55.h>
#include "pic18f87j50.c"

