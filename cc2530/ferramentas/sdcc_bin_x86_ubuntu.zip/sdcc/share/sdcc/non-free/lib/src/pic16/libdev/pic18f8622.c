/*
 * pic18f8622.c - device specific definitions
 */
#include "pic18f8722.c"
