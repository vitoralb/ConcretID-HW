/*
 * pic18f65j50.c - device specific definitions
 */

#include <pic18f65j50.h>
#include "pic18f67j50.c"

