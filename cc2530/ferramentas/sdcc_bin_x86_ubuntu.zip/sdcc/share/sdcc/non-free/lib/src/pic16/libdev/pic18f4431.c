/*
 * pic18f4431.c - device specific definitions
 */

#include "pic18f4331.c"

