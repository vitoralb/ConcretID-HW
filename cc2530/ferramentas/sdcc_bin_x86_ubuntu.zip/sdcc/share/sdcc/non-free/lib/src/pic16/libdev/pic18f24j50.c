/*
 * pic18f24j50.c - device specific definitions
 */
#include "pic18f46j50.c"
