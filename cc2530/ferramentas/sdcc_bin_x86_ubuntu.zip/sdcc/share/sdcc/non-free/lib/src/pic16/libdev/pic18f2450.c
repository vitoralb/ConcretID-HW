/*
 * pic18f2450.c - device specific definitions
 */

#include "pic18f4450.c"

