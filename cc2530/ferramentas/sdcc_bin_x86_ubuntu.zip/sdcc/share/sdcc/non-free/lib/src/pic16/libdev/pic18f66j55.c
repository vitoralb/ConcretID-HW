/*
 * pic18f66j55.c - device specific definitions
 */

#include <pic18f66j55.h>
#include "pic18f67j50.c"

