/*
 * pic18f2515.c - device specific definitions
 */

#include "pic18f4610.c"

