/*
 * pic18f2580.c - device specific definitions
 */

#include "pic18f4580.c"

