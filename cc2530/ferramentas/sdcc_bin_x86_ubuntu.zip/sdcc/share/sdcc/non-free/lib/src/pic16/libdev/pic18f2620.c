/* 
 * pic18f2620.c - PIC18F2620 Device Library Sources
 */

#include "pic18f4620.c" /* just the same, but in a different package */

