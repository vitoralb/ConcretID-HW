/*
 * pic18f4320.c - PIC18F4320 Device Library Source
 *
 * This file is part of the GNU PIC Library.
 *
 * January, 2004
 * The GNU PIC Library is maintained by,
 * 	Vangelis Rokas <vrokas@otenet.gr>
 *
 * $Id: pic18f4320.c 6002 2010-10-04 19:54:39Z borutr $
 *
 */

#include "pic18f4220.c"

