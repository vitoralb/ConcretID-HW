/*
 * pic18f67j60.c - device specific definitions
 */

#include "pic18f66j60.c"

