/*
 * pic18f97j60.c - device specific definitions
 */

#include "pic18f96j60.c"

