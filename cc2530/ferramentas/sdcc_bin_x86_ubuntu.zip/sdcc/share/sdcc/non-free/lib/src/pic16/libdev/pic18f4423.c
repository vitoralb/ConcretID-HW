/*
 * pic18f4423.c - device specific definitions
 */

#include "pic18f4523.c"

