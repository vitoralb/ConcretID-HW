/*
 * pic18f2423.c - device specific definitions
 */

#include "pic18f4523.c"

