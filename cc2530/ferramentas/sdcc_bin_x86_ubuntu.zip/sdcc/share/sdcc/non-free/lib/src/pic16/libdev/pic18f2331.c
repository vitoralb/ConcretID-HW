/*
 * pic18f2331.c - device specific definitions
 */

#include "pic18f4331.c"

