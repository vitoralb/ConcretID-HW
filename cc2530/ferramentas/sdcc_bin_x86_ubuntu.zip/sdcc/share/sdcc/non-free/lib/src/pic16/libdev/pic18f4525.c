/* 
 * pic18f4525.c - PIC18F4525 Device Library Sources
 */

#include "pic18f4620.c" /* just the same as the 4620 but with less eeprom */

