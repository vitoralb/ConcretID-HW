/*
 * pic18f6527.c - device specific definitions
 */
#include "pic18f8722.c"
