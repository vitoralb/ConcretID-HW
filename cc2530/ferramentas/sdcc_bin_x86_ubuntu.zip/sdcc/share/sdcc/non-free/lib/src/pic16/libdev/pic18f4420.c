/*
 * pic18f4420.c - device specific definitions
 *
 * This file is part of the GNU PIC library for SDCC,
 * originally devised by Vangelis Rokas <vrokas AT otenet.gr>
 *
 * (c) 2007 by Raphael Neider <rneider AT web.de>
 */

#include "pic18f4520.c"

