/*
 * pic18f2525.c - Device Library Sources
 */

#include "pic18f4620.c"

