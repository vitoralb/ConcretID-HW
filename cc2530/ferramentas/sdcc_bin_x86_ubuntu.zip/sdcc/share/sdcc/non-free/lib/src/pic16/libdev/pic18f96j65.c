/*
 * pic18f96j65.c - device specific definitions
 */

#include "pic18f96j60.c"

